"use strict";

var cov_1t4fmynnic = function () {
  var path = "/Users/korsanstudio/projekty/2018/syncano/sockets-dev/syncano/syncano-socket-messenger-bot/src/webhook.ts",
      hash = "f64d587bb594de972b31ee7b8242c5f49d81672f",
      Function = function () {}.constructor,
      global = new Function('return this')(),
      gcv = "__coverage__",
      coverageData = {
    path: "/Users/korsanstudio/projekty/2018/syncano/sockets-dev/syncano/syncano-socket-messenger-bot/src/webhook.ts",
    statementMap: {
      "0": {
        start: {
          line: 29,
          column: 20
        },
        end: {
          line: 29,
          column: 31
        }
      },
      "1": {
        start: {
          line: 31,
          column: 4
        },
        end: {
          line: 37,
          column: 5
        }
      },
      "2": {
        start: {
          line: 32,
          column: 6
        },
        end: {
          line: 36,
          column: 7
        }
      },
      "3": {
        start: {
          line: 33,
          column: 8
        },
        end: {
          line: 33,
          column: 39
        }
      },
      "4": {
        start: {
          line: 35,
          column: 8
        },
        end: {
          line: 35,
          column: 37
        }
      },
      "5": {
        start: {
          line: 39,
          column: 4
        },
        end: {
          line: 51,
          column: 5
        }
      },
      "6": {
        start: {
          line: 40,
          column: 30
        },
        end: {
          line: 40,
          column: 53
        }
      },
      "7": {
        start: {
          line: 41,
          column: 6
        },
        end: {
          line: 50,
          column: 7
        }
      },
      "8": {
        start: {
          line: 42,
          column: 24
        },
        end: {
          line: 42,
          column: 42
        }
      },
      "9": {
        start: {
          line: 43,
          column: 23
        },
        end: {
          line: 43,
          column: 40
        }
      },
      "10": {
        start: {
          line: 45,
          column: 8
        },
        end: {
          line: 49,
          column: 9
        }
      },
      "11": {
        start: {
          line: 46,
          column: 23
        },
        end: {
          line: 46,
          column: 43
        }
      },
      "12": {
        start: {
          line: 47,
          column: 10
        },
        end: {
          line: 47,
          column: 48
        }
      },
      "13": {
        start: {
          line: 48,
          column: 10
        },
        end: {
          line: 48,
          column: 63
        }
      },
      "14": {
        start: {
          line: 55,
          column: 22
        },
        end: {
          line: 55,
          column: 39
        }
      }
    },
    fnMap: {
      "0": {
        name: "(anonymous_0)",
        decl: {
          start: {
            line: 25,
            column: 2
          },
          end: {
            line: 25,
            column: 3
          }
        },
        loc: {
          start: {
            line: 28,
            column: 4
          },
          end: {
            line: 52,
            column: 3
          }
        },
        line: 28
      },
      "1": {
        name: "(anonymous_1)",
        decl: {
          start: {
            line: 55,
            column: 15
          },
          end: {
            line: 55,
            column: 16
          }
        },
        loc: {
          start: {
            line: 55,
            column: 22
          },
          end: {
            line: 55,
            column: 39
          }
        },
        line: 55
      }
    },
    branchMap: {
      "0": {
        loc: {
          start: {
            line: 31,
            column: 4
          },
          end: {
            line: 37,
            column: 5
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 31,
            column: 4
          },
          end: {
            line: 37,
            column: 5
          }
        }, {
          start: {
            line: 31,
            column: 4
          },
          end: {
            line: 37,
            column: 5
          }
        }],
        line: 31
      },
      "1": {
        loc: {
          start: {
            line: 32,
            column: 6
          },
          end: {
            line: 36,
            column: 7
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 32,
            column: 6
          },
          end: {
            line: 36,
            column: 7
          }
        }, {
          start: {
            line: 32,
            column: 6
          },
          end: {
            line: 36,
            column: 7
          }
        }],
        line: 32
      },
      "2": {
        loc: {
          start: {
            line: 39,
            column: 4
          },
          end: {
            line: 51,
            column: 5
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 39,
            column: 4
          },
          end: {
            line: 51,
            column: 5
          }
        }, {
          start: {
            line: 39,
            column: 4
          },
          end: {
            line: 51,
            column: 5
          }
        }],
        line: 39
      },
      "3": {
        loc: {
          start: {
            line: 39,
            column: 8
          },
          end: {
            line: 39,
            column: 62
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 39,
            column: 8
          },
          end: {
            line: 39,
            column: 18
          }
        }, {
          start: {
            line: 39,
            column: 22
          },
          end: {
            line: 39,
            column: 35
          }
        }, {
          start: {
            line: 39,
            column: 39
          },
          end: {
            line: 39,
            column: 62
          }
        }],
        line: 39
      },
      "4": {
        loc: {
          start: {
            line: 45,
            column: 8
          },
          end: {
            line: 49,
            column: 9
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 45,
            column: 8
          },
          end: {
            line: 49,
            column: 9
          }
        }, {
          start: {
            line: 45,
            column: 8
          },
          end: {
            line: 49,
            column: 9
          }
        }],
        line: 45
      },
      "5": {
        loc: {
          start: {
            line: 45,
            column: 12
          },
          end: {
            line: 45,
            column: 51
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 45,
            column: 12
          },
          end: {
            line: 45,
            column: 27
          }
        }, {
          start: {
            line: 45,
            column: 31
          },
          end: {
            line: 45,
            column: 51
          }
        }],
        line: 45
      }
    },
    s: {
      "0": 0,
      "1": 0,
      "2": 0,
      "3": 0,
      "4": 0,
      "5": 0,
      "6": 0,
      "7": 0,
      "8": 0,
      "9": 0,
      "10": 0,
      "11": 0,
      "12": 0,
      "13": 0,
      "14": 0
    },
    f: {
      "0": 0,
      "1": 0
    },
    b: {
      "0": [0, 0],
      "1": [0, 0],
      "2": [0, 0],
      "3": [0, 0, 0],
      "4": [0, 0],
      "5": [0, 0]
    },
    _coverageSchema: "332fd63041d2c1bcb487cc26dd0d5f7d97098a6c"
  },
      coverage = global[gcv] || (global[gcv] = {});

  if (coverage[path] && coverage[path].hash === hash) {
    return coverage[path];
  }

  coverageData.hash = hash;
  return coverage[path] = coverageData;
}();

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var S = _interopRequireWildcard(require("@eyedea/syncano"));

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) { var desc = Object.defineProperty && Object.getOwnPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : {}; if (desc.get || desc.set) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } } newObj.default = obj; return newObj; } }

class Endpoint extends (S.Endpoint) {
  async run({
    response,
    event
  }, {
    args
  }) {
    cov_1t4fmynnic.f[0]++;
    const {
      debug
    } = (cov_1t4fmynnic.s[0]++, this.logger);
    cov_1t4fmynnic.s[1]++;

    if (args['hub.mode'] === 'subscribe') {
      cov_1t4fmynnic.b[0][0]++;
      cov_1t4fmynnic.s[2]++;

      if (args['hub.verify_token'] === 'messenger-bot') {
        cov_1t4fmynnic.b[1][0]++;
        cov_1t4fmynnic.s[3]++;
        response(args['hub.challenge']);
      } else {
        cov_1t4fmynnic.b[1][1]++;
        cov_1t4fmynnic.s[4]++;
        response('Wrong token!', 400);
      }
    } else {
      cov_1t4fmynnic.b[0][1]++;
    }

    cov_1t4fmynnic.s[5]++;

    if ((cov_1t4fmynnic.b[3][0]++, args.entry) && (cov_1t4fmynnic.b[3][1]++, args.entry[0]) && (cov_1t4fmynnic.b[3][2]++, args.entry[0].messaging)) {
      cov_1t4fmynnic.b[2][0]++;
      const messagingEvents = (cov_1t4fmynnic.s[6]++, args.entry[0].messaging);
      cov_1t4fmynnic.s[7]++;

      for (let i = 0; i < messagingEvents.length; i++) {
        const fbEvent = (cov_1t4fmynnic.s[8]++, messagingEvents[i]);
        const sender = (cov_1t4fmynnic.s[9]++, fbEvent.sender.id);
        cov_1t4fmynnic.s[10]++;

        if ((cov_1t4fmynnic.b[5][0]++, fbEvent.message) && (cov_1t4fmynnic.b[5][1]++, fbEvent.message.text)) {
          cov_1t4fmynnic.b[4][0]++;
          const text = (cov_1t4fmynnic.s[11]++, fbEvent.message.text);
          cov_1t4fmynnic.s[12]++;
          debug('Sending event', {
            text,
            sender
          });
          cov_1t4fmynnic.s[13]++;
          return event.emit('message-received', {
            text,
            sender
          });
        } else {
          cov_1t4fmynnic.b[4][1]++;
        }
      }
    } else {
      cov_1t4fmynnic.b[2][1]++;
    }
  }

}

var _default = ctx => {
  cov_1t4fmynnic.f[1]++;
  cov_1t4fmynnic.s[14]++;
  return new Endpoint(ctx);
};

exports.default = _default;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy93ZWJob29rLnRzIl0sIm5hbWVzIjpbIkVuZHBvaW50IiwiUyIsInJ1biIsInJlc3BvbnNlIiwiZXZlbnQiLCJhcmdzIiwiZGVidWciLCJsb2dnZXIiLCJlbnRyeSIsIm1lc3NhZ2luZyIsIm1lc3NhZ2luZ0V2ZW50cyIsImkiLCJsZW5ndGgiLCJmYkV2ZW50Iiwic2VuZGVyIiwiaWQiLCJtZXNzYWdlIiwidGV4dCIsImVtaXQiLCJjdHgiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7Ozs7QUF1QkEsTUFBTUEsUUFBTixVQUF1QkMsQ0FBQyxDQUFDRCxRQUF6QixFQUFrQztBQUNoQyxRQUFNRSxHQUFOLENBQ0U7QUFBQ0MsSUFBQUEsUUFBRDtBQUFXQyxJQUFBQTtBQUFYLEdBREYsRUFFRTtBQUFDQyxJQUFBQTtBQUFELEdBRkYsRUFHRTtBQUFBO0FBQ0EsVUFBTTtBQUFDQyxNQUFBQTtBQUFELGdDQUFVLEtBQUtDLE1BQWYsQ0FBTjtBQURBOztBQUdBLFFBQUlGLElBQUksQ0FBQyxVQUFELENBQUosS0FBcUIsV0FBekIsRUFBc0M7QUFBQTtBQUFBOztBQUNwQyxVQUFJQSxJQUFJLENBQUMsa0JBQUQsQ0FBSixLQUE2QixlQUFqQyxFQUFrRDtBQUFBO0FBQUE7QUFDaERGLFFBQUFBLFFBQVEsQ0FBQ0UsSUFBSSxDQUFDLGVBQUQsQ0FBTCxDQUFSO0FBQ0QsT0FGRCxNQUVPO0FBQUE7QUFBQTtBQUNMRixRQUFBQSxRQUFRLENBQUMsY0FBRCxFQUFpQixHQUFqQixDQUFSO0FBQ0Q7QUFDRixLQU5EO0FBQUE7QUFBQTs7QUFIQTs7QUFXQSxRQUFJLDJCQUFBRSxJQUFJLENBQUNHLEtBQUwsZ0NBQWNILElBQUksQ0FBQ0csS0FBTCxDQUFXLENBQVgsQ0FBZCxnQ0FBK0JILElBQUksQ0FBQ0csS0FBTCxDQUFXLENBQVgsRUFBY0MsU0FBN0MsQ0FBSixFQUE0RDtBQUFBO0FBQzFELFlBQU1DLGVBQWUsMkJBQUdMLElBQUksQ0FBQ0csS0FBTCxDQUFXLENBQVgsRUFBY0MsU0FBakIsQ0FBckI7QUFEMEQ7O0FBRTFELFdBQUssSUFBSUUsQ0FBQyxHQUFHLENBQWIsRUFBZ0JBLENBQUMsR0FBR0QsZUFBZSxDQUFDRSxNQUFwQyxFQUE0Q0QsQ0FBQyxFQUE3QyxFQUFpRDtBQUMvQyxjQUFNRSxPQUFPLDJCQUFHSCxlQUFlLENBQUNDLENBQUQsQ0FBbEIsQ0FBYjtBQUNBLGNBQU1HLE1BQU0sMkJBQUdELE9BQU8sQ0FBQ0MsTUFBUixDQUFlQyxFQUFsQixDQUFaO0FBRitDOztBQUkvQyxZQUFJLDJCQUFBRixPQUFPLENBQUNHLE9BQVIsZ0NBQW1CSCxPQUFPLENBQUNHLE9BQVIsQ0FBZ0JDLElBQW5DLENBQUosRUFBNkM7QUFBQTtBQUMzQyxnQkFBTUEsSUFBSSw0QkFBR0osT0FBTyxDQUFDRyxPQUFSLENBQWdCQyxJQUFuQixDQUFWO0FBRDJDO0FBRTNDWCxVQUFBQSxLQUFLLENBQUMsZUFBRCxFQUFrQjtBQUFDVyxZQUFBQSxJQUFEO0FBQU9ILFlBQUFBO0FBQVAsV0FBbEIsQ0FBTDtBQUYyQztBQUczQyxpQkFBT1YsS0FBSyxDQUFDYyxJQUFOLENBQVcsa0JBQVgsRUFBK0I7QUFBQ0QsWUFBQUEsSUFBRDtBQUFPSCxZQUFBQTtBQUFQLFdBQS9CLENBQVA7QUFDRCxTQUpEO0FBQUE7QUFBQTtBQUtEO0FBQ0YsS0FaRDtBQUFBO0FBQUE7QUFhRDs7QUE1QitCOztlQStCbkJLLEdBQUcsSUFBSTtBQUFBO0FBQUE7QUFBQSxhQUFJbkIsUUFBSixDQUFhbUIsR0FBYjtBQUFpQixDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0ICogYXMgUyBmcm9tICdAZXllZGVhL3N5bmNhbm8nXG5cbmludGVyZmFjZSBFbnRyeSB7XG4gIG1lc3NhZ2luZzogRXZlbnRbXVxufVxuXG5pbnRlcmZhY2UgRXZlbnQge1xuICBzZW5kZXI6IFNlbmRlclxuICBtZXNzYWdlOiBNZXNzYWdlXG59XG5cbmludGVyZmFjZSBNZXNzYWdlIHtcbiAgdGV4dDogc3RyaW5nXG59XG5cbmludGVyZmFjZSBTZW5kZXIge1xuICBpZDogbnVtYmVyXG59XG5cbmludGVyZmFjZSBBcmdzIHtcbiAgZW50cnk6IEVudHJ5W11cbn1cblxuY2xhc3MgRW5kcG9pbnQgZXh0ZW5kcyBTLkVuZHBvaW50IHtcbiAgYXN5bmMgcnVuKFxuICAgIHtyZXNwb25zZSwgZXZlbnR9OiBTLkNvcmUsXG4gICAge2FyZ3N9OiBTLkNvbnRleHQ8QXJncz5cbiAgKSB7XG4gICAgY29uc3Qge2RlYnVnfSA9IHRoaXMubG9nZ2VyXG5cbiAgICBpZiAoYXJnc1snaHViLm1vZGUnXSA9PT0gJ3N1YnNjcmliZScpIHtcbiAgICAgIGlmIChhcmdzWydodWIudmVyaWZ5X3Rva2VuJ10gPT09ICdtZXNzZW5nZXItYm90Jykge1xuICAgICAgICByZXNwb25zZShhcmdzWydodWIuY2hhbGxlbmdlJ10pXG4gICAgICB9IGVsc2Uge1xuICAgICAgICByZXNwb25zZSgnV3JvbmcgdG9rZW4hJywgNDAwKVxuICAgICAgfVxuICAgIH1cblxuICAgIGlmIChhcmdzLmVudHJ5ICYmIGFyZ3MuZW50cnlbMF0gJiYgYXJncy5lbnRyeVswXS5tZXNzYWdpbmcpIHtcbiAgICAgIGNvbnN0IG1lc3NhZ2luZ0V2ZW50cyA9IGFyZ3MuZW50cnlbMF0ubWVzc2FnaW5nXG4gICAgICBmb3IgKGxldCBpID0gMDsgaSA8IG1lc3NhZ2luZ0V2ZW50cy5sZW5ndGg7IGkrKykge1xuICAgICAgICBjb25zdCBmYkV2ZW50ID0gbWVzc2FnaW5nRXZlbnRzW2ldXG4gICAgICAgIGNvbnN0IHNlbmRlciA9IGZiRXZlbnQuc2VuZGVyLmlkXG5cbiAgICAgICAgaWYgKGZiRXZlbnQubWVzc2FnZSAmJiBmYkV2ZW50Lm1lc3NhZ2UudGV4dCkge1xuICAgICAgICAgIGNvbnN0IHRleHQgPSBmYkV2ZW50Lm1lc3NhZ2UudGV4dFxuICAgICAgICAgIGRlYnVnKCdTZW5kaW5nIGV2ZW50Jywge3RleHQsIHNlbmRlcn0pXG4gICAgICAgICAgcmV0dXJuIGV2ZW50LmVtaXQoJ21lc3NhZ2UtcmVjZWl2ZWQnLCB7dGV4dCwgc2VuZGVyfSlcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgfVxufVxuXG5leHBvcnQgZGVmYXVsdCBjdHggPT4gbmV3IEVuZHBvaW50KGN0eClcbiJdfQ==