"use strict";

var cov_2agzbp52a = function () {
  var path = "/Users/korsanstudio/projekty/2018/syncano/sockets-dev/syncano/syncano-socket-messenger-bot/src/send-message.ts",
      hash = "fa32be0fc566b5495053e93587f5ca6a5c02d4bf",
      Function = function () {}.constructor,
      global = new Function('return this')(),
      gcv = "__coverage__",
      coverageData = {
    path: "/Users/korsanstudio/projekty/2018/syncano/sockets-dev/syncano/syncano-socket-messenger-bot/src/send-message.ts",
    statementMap: {
      "0": {
        start: {
          line: 15,
          column: 24
        },
        end: {
          line: 31,
          column: 5
        }
      },
      "1": {
        start: {
          line: 16,
          column: 6
        },
        end: {
          line: 30,
          column: 8
        }
      },
      "2": {
        start: {
          line: 25,
          column: 8
        },
        end: {
          line: 29,
          column: 9
        }
      },
      "3": {
        start: {
          line: 26,
          column: 10
        },
        end: {
          line: 26,
          column: 55
        }
      },
      "4": {
        start: {
          line: 27,
          column: 15
        },
        end: {
          line: 29,
          column: 9
        }
      },
      "5": {
        start: {
          line: 28,
          column: 10
        },
        end: {
          line: 28,
          column: 53
        }
      },
      "6": {
        start: {
          line: 33,
          column: 4
        },
        end: {
          line: 33,
          column: 47
        }
      },
      "7": {
        start: {
          line: 35,
          column: 4
        },
        end: {
          line: 37,
          column: 5
        }
      },
      "8": {
        start: {
          line: 36,
          column: 6
        },
        end: {
          line: 36,
          column: 61
        }
      },
      "9": {
        start: {
          line: 41,
          column: 22
        },
        end: {
          line: 41,
          column: 39
        }
      }
    },
    fnMap: {
      "0": {
        name: "(anonymous_0)",
        decl: {
          start: {
            line: 11,
            column: 2
          },
          end: {
            line: 11,
            column: 3
          }
        },
        loc: {
          start: {
            line: 14,
            column: 4
          },
          end: {
            line: 38,
            column: 3
          }
        },
        line: 14
      },
      "1": {
        name: "(anonymous_1)",
        decl: {
          start: {
            line: 15,
            column: 24
          },
          end: {
            line: 15,
            column: 25
          }
        },
        loc: {
          start: {
            line: 15,
            column: 49
          },
          end: {
            line: 31,
            column: 5
          }
        },
        line: 15
      },
      "2": {
        name: "(anonymous_2)",
        decl: {
          start: {
            line: 24,
            column: 9
          },
          end: {
            line: 24,
            column: 10
          }
        },
        loc: {
          start: {
            line: 24,
            column: 36
          },
          end: {
            line: 30,
            column: 7
          }
        },
        line: 24
      },
      "3": {
        name: "(anonymous_3)",
        decl: {
          start: {
            line: 41,
            column: 15
          },
          end: {
            line: 41,
            column: 16
          }
        },
        loc: {
          start: {
            line: 41,
            column: 22
          },
          end: {
            line: 41,
            column: 39
          }
        },
        line: 41
      }
    },
    branchMap: {
      "0": {
        loc: {
          start: {
            line: 25,
            column: 8
          },
          end: {
            line: 29,
            column: 9
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 25,
            column: 8
          },
          end: {
            line: 29,
            column: 9
          }
        }, {
          start: {
            line: 25,
            column: 8
          },
          end: {
            line: 29,
            column: 9
          }
        }],
        line: 25
      },
      "1": {
        loc: {
          start: {
            line: 27,
            column: 15
          },
          end: {
            line: 29,
            column: 9
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 27,
            column: 15
          },
          end: {
            line: 29,
            column: 9
          }
        }, {
          start: {
            line: 27,
            column: 15
          },
          end: {
            line: 29,
            column: 9
          }
        }],
        line: 27
      },
      "2": {
        loc: {
          start: {
            line: 35,
            column: 4
          },
          end: {
            line: 37,
            column: 5
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 35,
            column: 4
          },
          end: {
            line: 37,
            column: 5
          }
        }, {
          start: {
            line: 35,
            column: 4
          },
          end: {
            line: 37,
            column: 5
          }
        }],
        line: 35
      }
    },
    s: {
      "0": 0,
      "1": 0,
      "2": 0,
      "3": 0,
      "4": 0,
      "5": 0,
      "6": 0,
      "7": 0,
      "8": 0,
      "9": 0
    },
    f: {
      "0": 0,
      "1": 0,
      "2": 0,
      "3": 0
    },
    b: {
      "0": [0, 0],
      "1": [0, 0],
      "2": [0, 0]
    },
    _coverageSchema: "332fd63041d2c1bcb487cc26dd0d5f7d97098a6c"
  },
      coverage = global[gcv] || (global[gcv] = {});

  if (coverage[path] && coverage[path].hash === hash) {
    return coverage[path];
  }

  coverageData.hash = hash;
  return coverage[path] = coverageData;
}();

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _request = _interopRequireDefault(require("request"));

var S = _interopRequireWildcard(require("@eyedea/syncano"));

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) { var desc = Object.defineProperty && Object.getOwnPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : {}; if (desc.get || desc.set) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } } newObj.default = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

class Endpoint extends (S.Endpoint) {
  async run({}, {
    args,
    config
  }) {
    cov_2agzbp52a.f[0]++;
    cov_2agzbp52a.s[0]++;

    const sendMessage = (messageData, sender) => {
      cov_2agzbp52a.f[1]++;
      cov_2agzbp52a.s[1]++;
      (0, _request.default)({
        url: 'https://graph.facebook.com/v2.6/me/messages',
        qs: {
          access_token: config.FACEBOOK_APP_TOKEN
        },
        method: 'POST',
        json: {
          recipient: {
            id: sender
          },
          message: messageData
        }
      }, function (error, response) {
        cov_2agzbp52a.f[2]++;
        cov_2agzbp52a.s[2]++;

        if (error) {
          cov_2agzbp52a.b[0][0]++;
          cov_2agzbp52a.s[3]++;
          console.log('Error sending message: ', error);
        } else {
          cov_2agzbp52a.b[0][1]++;
          cov_2agzbp52a.s[4]++;

          if (response.body.error) {
            cov_2agzbp52a.b[1][0]++;
            cov_2agzbp52a.s[5]++;
            console.log('Error: ', response.body.error);
          } else {
            cov_2agzbp52a.b[1][1]++;
          }
        }
      });
    };

    cov_2agzbp52a.s[6]++;
    sendMessage({
      text: args.text
    }, args.sender);
    cov_2agzbp52a.s[7]++;

    if (args.attachment) {
      cov_2agzbp52a.b[2][0]++;
      cov_2agzbp52a.s[8]++;
      sendMessage({
        attachment: args.attachment
      }, args.sender);
    } else {
      cov_2agzbp52a.b[2][1]++;
    }
  }

}

var _default = ctx => {
  cov_2agzbp52a.f[3]++;
  cov_2agzbp52a.s[9]++;
  return new Endpoint(ctx);
};

exports.default = _default;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9zZW5kLW1lc3NhZ2UudHMiXSwibmFtZXMiOlsiRW5kcG9pbnQiLCJTIiwicnVuIiwiYXJncyIsImNvbmZpZyIsInNlbmRNZXNzYWdlIiwibWVzc2FnZURhdGEiLCJzZW5kZXIiLCJ1cmwiLCJxcyIsImFjY2Vzc190b2tlbiIsIkZBQ0VCT09LX0FQUF9UT0tFTiIsIm1ldGhvZCIsImpzb24iLCJyZWNpcGllbnQiLCJpZCIsIm1lc3NhZ2UiLCJlcnJvciIsInJlc3BvbnNlIiwiY29uc29sZSIsImxvZyIsImJvZHkiLCJ0ZXh0IiwiYXR0YWNobWVudCIsImN0eCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7O0FBQ0E7Ozs7OztBQVFBLE1BQU1BLFFBQU4sVUFBdUJDLENBQUMsQ0FBQ0QsUUFBekIsRUFBd0M7QUFDdEMsUUFBTUUsR0FBTixDQUNFLEVBREYsRUFFRTtBQUFDQyxJQUFBQSxJQUFEO0FBQU9DLElBQUFBO0FBQVAsR0FGRixFQUdFO0FBQUE7QUFBQTs7QUFDQSxVQUFNQyxXQUFXLEdBQUcsQ0FBQ0MsV0FBRCxFQUFjQyxNQUFkLEtBQXlCO0FBQUE7QUFBQTtBQUMzQyw0QkFBUTtBQUNOQyxRQUFBQSxHQUFHLEVBQUUsNkNBREM7QUFFTkMsUUFBQUEsRUFBRSxFQUFFO0FBQUNDLFVBQUFBLFlBQVksRUFBRU4sTUFBTSxDQUFDTztBQUF0QixTQUZFO0FBR05DLFFBQUFBLE1BQU0sRUFBRSxNQUhGO0FBSU5DLFFBQUFBLElBQUksRUFBRTtBQUNKQyxVQUFBQSxTQUFTLEVBQUU7QUFBQ0MsWUFBQUEsRUFBRSxFQUFFUjtBQUFMLFdBRFA7QUFFSlMsVUFBQUEsT0FBTyxFQUFFVjtBQUZMO0FBSkEsT0FBUixFQVFHLFVBQVVXLEtBQVYsRUFBaUJDLFFBQWpCLEVBQTJCO0FBQUE7QUFBQTs7QUFDNUIsWUFBSUQsS0FBSixFQUFXO0FBQUE7QUFBQTtBQUNURSxVQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSx5QkFBWixFQUF1Q0gsS0FBdkM7QUFDRCxTQUZELE1BRU87QUFBQTtBQUFBOztBQUFBLGNBQUlDLFFBQVEsQ0FBQ0csSUFBVCxDQUFjSixLQUFsQixFQUF5QjtBQUFBO0FBQUE7QUFDOUJFLFlBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFNBQVosRUFBdUJGLFFBQVEsQ0FBQ0csSUFBVCxDQUFjSixLQUFyQztBQUNELFdBRk07QUFBQTtBQUFBO0FBRU47QUFDRixPQWREO0FBZUQsS0FoQkQ7O0FBREE7QUFtQkFaLElBQUFBLFdBQVcsQ0FBQztBQUFDaUIsTUFBQUEsSUFBSSxFQUFFbkIsSUFBSSxDQUFDbUI7QUFBWixLQUFELEVBQW9CbkIsSUFBSSxDQUFDSSxNQUF6QixDQUFYO0FBbkJBOztBQXFCQSxRQUFJSixJQUFJLENBQUNvQixVQUFULEVBQXFCO0FBQUE7QUFBQTtBQUNuQmxCLE1BQUFBLFdBQVcsQ0FBQztBQUFDa0IsUUFBQUEsVUFBVSxFQUFFcEIsSUFBSSxDQUFDb0I7QUFBbEIsT0FBRCxFQUFnQ3BCLElBQUksQ0FBQ0ksTUFBckMsQ0FBWDtBQUNELEtBRkQ7QUFBQTtBQUFBO0FBR0Q7O0FBNUJxQzs7ZUErQnpCaUIsR0FBRyxJQUFJO0FBQUE7QUFBQTtBQUFBLGFBQUl4QixRQUFKLENBQWF3QixHQUFiO0FBQWlCLEMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgcmVxdWVzdCBmcm9tICdyZXF1ZXN0J1xuaW1wb3J0ICogYXMgUyBmcm9tICdAZXllZGVhL3N5bmNhbm8nXG5cbmludGVyZmFjZSBBcmdzIHtcbiAgdGV4dDogc3RyaW5nXG4gIHNlbmRlcjogc3RyaW5nXG4gIGF0dGFjaG1lbnQ6IGFueVxufVxuXG5jbGFzcyBFbmRwb2ludCBleHRlbmRzIFMuRW5kcG9pbnQ8QXJncz4ge1xuICBhc3luYyBydW4oXG4gICAge306IFMuQ29yZSxcbiAgICB7YXJncywgY29uZmlnfTogUy5Db250ZXh0PEFyZ3M+XG4gICkge1xuICAgIGNvbnN0IHNlbmRNZXNzYWdlID0gKG1lc3NhZ2VEYXRhLCBzZW5kZXIpID0+IHtcbiAgICAgIHJlcXVlc3Qoe1xuICAgICAgICB1cmw6ICdodHRwczovL2dyYXBoLmZhY2Vib29rLmNvbS92Mi42L21lL21lc3NhZ2VzJyxcbiAgICAgICAgcXM6IHthY2Nlc3NfdG9rZW46IGNvbmZpZy5GQUNFQk9PS19BUFBfVE9LRU59LFxuICAgICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgICAganNvbjoge1xuICAgICAgICAgIHJlY2lwaWVudDoge2lkOiBzZW5kZXJ9LFxuICAgICAgICAgIG1lc3NhZ2U6IG1lc3NhZ2VEYXRhXG4gICAgICAgIH1cbiAgICAgIH0sIGZ1bmN0aW9uIChlcnJvciwgcmVzcG9uc2UpIHtcbiAgICAgICAgaWYgKGVycm9yKSB7XG4gICAgICAgICAgY29uc29sZS5sb2coJ0Vycm9yIHNlbmRpbmcgbWVzc2FnZTogJywgZXJyb3IpXG4gICAgICAgIH0gZWxzZSBpZiAocmVzcG9uc2UuYm9keS5lcnJvcikge1xuICAgICAgICAgIGNvbnNvbGUubG9nKCdFcnJvcjogJywgcmVzcG9uc2UuYm9keS5lcnJvcilcbiAgICAgICAgfVxuICAgICAgfSlcbiAgICB9XG5cbiAgICBzZW5kTWVzc2FnZSh7dGV4dDogYXJncy50ZXh0fSwgYXJncy5zZW5kZXIpXG5cbiAgICBpZiAoYXJncy5hdHRhY2htZW50KSB7XG4gICAgICBzZW5kTWVzc2FnZSh7YXR0YWNobWVudDogYXJncy5hdHRhY2htZW50fSwgYXJncy5zZW5kZXIpXG4gICAgfVxuICB9XG59XG5cbmV4cG9ydCBkZWZhdWx0IGN0eCA9PiBuZXcgRW5kcG9pbnQoY3R4KVxuIl19